package com.app.hubert.guide.listener;

import android.view.animation.Animation;

/**
 * Created by hubert on 2018/2/12.
 */

public abstract class AnimationListenerAdapter implements Animation.AnimationListener {
    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
