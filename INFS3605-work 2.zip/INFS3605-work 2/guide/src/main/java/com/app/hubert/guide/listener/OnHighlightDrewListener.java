package com.app.hubert.guide.listener;

import android.graphics.Canvas;
import android.graphics.RectF;

/**
 * Created by hubert on 2018/7/9.
 */
public interface OnHighlightDrewListener {

    void onHighlightDrew(Canvas canvas, RectF rectF);
}
