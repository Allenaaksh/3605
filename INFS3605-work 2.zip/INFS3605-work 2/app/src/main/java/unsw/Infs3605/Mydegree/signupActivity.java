package unsw.Infs3605.Mydegree;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.TextUtils;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class signupActivity extends AppCompatActivity {

    EditText mTextUsername;
    EditText mTextPassword;
    EditText mTextConfPassword;
    Button mButtonRegister;
    UserDatabaseHelper db;
    Button mButtonBack;
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance ();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        setTitle("Create Your Account");


        db = new UserDatabaseHelper(this);
        mTextUsername = findViewById(R.id.rusername);
        mTextPassword = findViewById(R.id.rpw);
        mTextConfPassword = findViewById(R.id.rpwconf);
        mButtonRegister = findViewById(R.id.create_btn);
        mButtonBack = findViewById(R.id.back_btn);
        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LoginIntent = new Intent(signupActivity.this, LoginActivity.class);
                startActivity(LoginIntent);

            }
        });

        mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = mTextUsername.getText().toString().trim();
                String psw = mTextPassword.getText().toString().trim();
                String cfpsw = mTextConfPassword.getText().toString().trim();


                if(TextUtils.isEmpty(mTextUsername.getText())) {
                    mTextUsername.setError("A valid username is required!");
                    return;
                }

                if(TextUtils.isEmpty(mTextPassword.getText())) {
                    mTextPassword.setError("Password cannot be empty!");
                    return;
                }

                if(TextUtils.isEmpty(mTextConfPassword.getText())) {
                    mTextConfPassword.setError("Please confirm your password!");
                    return;
                }

                if (psw.equals(cfpsw)) {

                    firebaseAuth.createUserWithEmailAndPassword (user,psw).addOnCompleteListener ( signupActivity.this, new OnCompleteListener<AuthResult> () {
                        @Override
                        public void onComplete ( @NonNull Task<AuthResult> task ) {
                            System.out.println ("???");

                            if(task.isSuccessful ()){
                                Toast.makeText(signupActivity.this, "Registered successfully!", Toast.LENGTH_SHORT).show();

                            }
                            else {
                                Toast.makeText(signupActivity.this, "Error: Registration unsuccessful", Toast.LENGTH_SHORT).show();
                            }


                        }
                    } );


////                    long val = db.addStudent(user, psw);
//                    if (val >=1) {
//                        Toast.makeText(signupActivity.this, "Registered successfully!", Toast.LENGTH_SHORT).show();
//                        Intent movetologin = new Intent(signupActivity.this, LoginActivity.class);
//                        startActivity(movetologin);
//                    } else {
//                        Toast.makeText(signupActivity.this, "Error: Registration unsuccessful", Toast.LENGTH_SHORT).show();
//                    }
                }


                else {
                    Toast.makeText(signupActivity.this, "Error: Password does not match!", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    @Override public void onBackPressed() {
        startActivity(new Intent(signupActivity.this, signupActivity.class));
        finish();
    }
}

