package unsw.Infs3605.Mydegree;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class LoginActivity extends AppCompatActivity {
    EditText mTextzid;
    EditText mTextPassword;
    Button mButtonLogin;
    Button mButtonSiup;
    UserDatabaseHelper db;
    User u = new User();
    TextView fp;

      FirebaseAuth firebaseAuth = FirebaseAuth.getInstance ();
       FirebaseFirestore db1= FirebaseFirestore.getInstance ();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.activity_login);
       // firebaseAuth =
        db = new UserDatabaseHelper(this);
        //db1 =
//        db1.collection ( "g" ).get ().addOnSuccessListener ( new OnSuccessListener<QuerySnapshot> () {
//            @Override
//            public void onSuccess ( QuerySnapshot queryDocumentSnapshots ) {
//                if(!queryDocumentSnapshots.isEmpty ()){
//                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments ();
//
//                }
//
//
//            }
//        } );

        mTextzid = findViewById(R.id.zid_input);
        mTextPassword = findViewById(R.id.pw_input);
        mButtonLogin = findViewById(R.id.login_btn);
        mButtonSiup = findViewById(R.id.reg_btn);
        mButtonSiup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerIntent = new Intent(LoginActivity.this, signupActivity.class);
                startActivity(registerIntent);
            }
        });


        mButtonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = mTextzid.getText().toString().trim();
                String pwd = mTextPassword.getText().toString().trim();
//                Boolean res = db.checkUsers(user, pwd);
                u.setUsername(user);
                System.out.println ("???");

                firebaseAuth.signInWithEmailAndPassword (user,pwd ).addOnCompleteListener ( LoginActivity.this, new OnCompleteListener<AuthResult> () {
                    @Override
                    public void onComplete ( @NonNull Task<AuthResult> task ) {
                        System.out.println ("???");

                        if(task.isSuccessful ()){
                            System.out.println ("???");
                           // FirebaseUser user =  firebaseAuth.getCurrentUser();
                            Intent LoginScreen = new Intent(LoginActivity.this, HomepageActivity.class);
                            startActivity(LoginScreen);
                            System.out.println ("???");
                        }
                        else {
                            System.out.println ("???");
                            System.out.println("Sign-in Failed: " + task.getException().getMessage());
                            Toast.makeText(LoginActivity.this,"Erorr Login",Toast.LENGTH_LONG).show();
                            System.out.println ("???");
//
//                            Intent LoginScreen = new Intent(LoginActivity.this, HomepageActivity.class);
//                            startActivity(LoginScreen);
    }
                        System.out.println ("...");

                    }
                } );



//                if (res == true) {
//                    u.setUsername(user);
//                    Intent LoginScreen = new Intent(LoginActivity.this, HomepageActivity.class);
//                    startActivity(LoginScreen);
//                } else {
//                    Toast.makeText(LoginActivity.this, "Error: Unable to log-in - could not find an existing user with that username and password!", Toast.LENGTH_SHORT).show();
//                }
            }
        });

        fp = findViewById(R.id.pwforgot);
        fp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerIntent = new Intent(LoginActivity.this, PasswrodfActivity.class);
                startActivity(registerIntent);
            }
        });
    }
}

